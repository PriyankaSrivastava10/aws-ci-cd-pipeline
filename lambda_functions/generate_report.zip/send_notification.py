"""
Your module description
"""
from logger import Logger
from awsclients import AwsClients
from cfnpipeline import CFNPipeline
import shutil
import os

loglevel = 'debug'
logger = Logger(loglevel=loglevel)
awsclient = AwsClients(logger)
pipeline_run = CFNPipeline(logger, awsclient)

class SendNotification(object):
    
    def __init__(self, logger, clients):
        """Initializes several variables, many are set in the consume_event method.

        Args:
            logger (obj): provide a logging object to use
            clients (obj): provide an instance of AwsClients to use for fetching boto3 clients
        """

        self.logger = logger
        self.clients = clients
        self.pipeline_name = None
        self.ci_configs = None
        self.job_data = None
        self.artifacts = None
        return
    
    def build_execution_report(
            self, pipeline_id=None, region=None,
            sns_topic=None, s3_bucket=None, s3_prefix='',
            s3_region=None, execution_id=None, configyml=None):
                
        templateNames = self.fetch_templateNames(configyml)
        logger.debug(templateNames)
        counter=0
        output = "Validation result for execution id: "+execution_id+"\n\n"
        output += "Templates Validated Successfully.\n\nThe Following templates were validated:\n\n" 
        for templateName in templateNames:
            counter+=1
            output += str(counter)+". " +templateName+"\n"
        #output = output.append(templateNames)
        logger.debug(output)
        
        if sns_topic:
            sns_region = sns_topic.split(':')[3]
            sns_client = self.clients.get('sns', sns_region)
            subject = "Validation Successful - %s" % (pipeline_id)
            sns_client.publish(TopicArn=sns_topic, Subject=subject[:100], Message=output)
        return output
        
    def fetch_templateNames(self, configyml):
        templateNames=[]
        for config in configyml.keys():
            for config_file in configyml[config]:
                for test in config_file['tests'].keys():
                    fname = config_file['tests'][test]['template_file']
                    templateNames.append(fname)
                    logger.debug("file: "+fname)
        logger.debug(templateNames)        
        return templateNames
        
  