from awsclients import AwsClients
from botocore.exceptions import ClientError
from cfnpipeline import CFNPipeline
from logger import Logger


loglevel = 'debug'
logger = Logger(loglevel=loglevel)
logger.info('New Lambda container initialised, logging configured.')
clients = AwsClients(logger)
pipeline_run = CFNPipeline(logger, clients)
err = 'error...'

def get_templates(configs):
    logger.debug("inside get templates...")
    logger.debug("configs...")
    logger.debug(configs)
    logger.debug("configs.keys()...")
    logger.debug(configs.keys())
    templates = []
    global err
   
    try:
        if configs is None:
            err = "No Congif Found"
            raise Exception
        elif configs.keys() is None:
            err = "No keys Present in Config File"
            raise Exception
        for artifact in configs.keys():
                logger.debug("configs[artifact]...")
                logger.debug(configs[artifact])
                if configs[artifact] is None or len(configs[artifact]) == 0:
                    logger.debug("inside for..")
                    err = "Config file does not exists or is blank"
                    logger.debug(err)
                    raise Exception
                for config in configs[artifact]:
                    logger.debug("config...")
                    logger.debug(config)
                    if config is None:
                        err = "Config File is Blank"
                        raise Exception
                    for test in config['tests'].keys():
                        logger.debug("test...")
                        logger.debug(test)
                        try:
                           t = [artifact, config['tests'][test]['template_file']]
                        except Exception:
                           err = "Template_file tag not defined"
                           return
                        logger.debug("t...")
                        logger.debug(t)
                        if t is None:
                            err = "No template_file present in config file for Tests = " + test
                            raise Exception
                        if t not in templates:
                            templates.append(t)
                            
        logger.debug("templates...")
        logger.debug(templates)
        #if len(templates) == 0:
         #   err = "No Templates to Validate"
          #  logger.error(err)
           # raise Exception
    except Exception as e:
        logger.error(err)
        return
    logger.debug(templates)
    return templates


def validate_template(artifact, template_name):
    logger.debug("inside validate templates...")
    logger.debug("artifact...")
    logger.debug(artifact)
    logger.debug("template_name...")
    logger.debug(template_name)
    try:
        url = pipeline_run.upload_template(artifact, template_name, pipeline_run.user_params["ScratchBucket"],
                                       pipeline_run.region)
    except Exception as e:
        logger.debug("inside exception")
        return "No Template named: "+template_name+" exists in the templates folder"
    cfn_client = clients.get('cloudformation')
    try:
        cfn_client.validate_template(TemplateURL=url)
    except ClientError as e:
        return e.message


def lambda_handler(event, context):
    try:
        logger.config(context.aws_request_id)
        logger.debug("Handler starting...")
        logger.debug(event)
        pipeline_run.consume_event(event, context, loglevel=loglevel)
        logger.info({'event': 'new_invoke'})
        errors = []
        successes = []
        global err
        logger.debug("calling get templates...")
        templates=[]
        templates = get_templates(pipeline_run.ci_configs)
        if templates==None or len(templates) == 0:
            err = "No Templates to Validate"
            logger.error(err)
            errors.append(err)
        if len(errors) > 0:
            msg = "%s validation failures %s" % (len(errors), errors)
            pipeline_run.put_job_failure(msg)
            logger.error(msg)
        else:
            for a, t in templates:
                logger.debug("calling  validate templates...")
                validation_failed = validate_template(a, t)
                logger.debug("validation_failed...")
                logger.debug(validation_failed)
                if validation_failed:
                    logger.debug("inside if validation_failed...")
                    errors.append([a, t, validation_failed])
                else:
                    successes.append('%s/%s' % (a, t))
        if len(errors) > 0:
            msg = "%s validation failures %s" % (len(errors), errors)
            pipeline_run.put_job_failure(msg)
            logger.error(msg)
        else:
            pipeline_run.put_job_success("Successfully validated: %s" % successes)
            logger.info("Successfully validated: %s" % successes)
    except Exception as e:
        logger.error("unhandled exception!", exc_info=1)
        pipeline_run.put_job_failure(str(e))
