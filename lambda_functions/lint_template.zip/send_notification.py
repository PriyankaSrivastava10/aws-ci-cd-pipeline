from logger import Logger
from awsclients import AwsClients
import botocore
import boto3

loglevel = 'debug'
logger = Logger(loglevel=loglevel)
awsclient = AwsClients(logger)

class SendNotification(object):
    def __init__(self, logger, clients):
        self.clients = clients
        self.logger = logger
        return
    
    def notify_errors(self, pipeline_id=None, sns_topic=None, errormsg='', region=None, execution_id=None):
        output = "Details for execution id: " +execution_id+"\n\n"
       # topic = self.clients.list_topics()
        logger.debug("Failure Notification...")
       # logger.debug(topic)
        logger.debug(sns_topic)
        logger.debug(pipeline_id)
        #logger.debug("Failure Notification..." + output)
        
        output+=errormsg
        
        if sns_topic:
            sns_region = sns_topic.split(':')[3]
            sns_client = self.clients.get('sns', sns_region)
            subject = "Validation Failure - %s" % (pipeline_id)
            sns_client.publish(TopicArn=sns_topic, Subject=subject[:100], Message=output)
        return output
        
                    
    def capture_logs(self, region=None, pipeline_name=''):
       client = boto3.client('logs')
       
       logGroup = '/aws/codebuild/CFN-Lint-' + pipeline_name
       logger.debug("logGroup..."+logGroup)
       logs_client= client.describe_log_streams(
           logGroupName=logGroup,
           orderBy='LastEventTime',
           descending=True,
           limit=1)
       
       logger.debug("logs_client...")
       logStreams=logs_client.get('logStreams')
       logStreamName=logStreams[0].get('logStreamName')
       logger.debug('log stream name: '+logStreamName)
       
       startTime = self.getTimeStamp(client=client,
           logGroup=logGroup, 
           logStreamName=logStreamName,
           filterPattern='ExecutionDetailsStart'
           )
       endTime = self.getTimeStamp(client=client,
           logGroup=logGroup, 
           logStreamName=logStreamName,
           filterPattern='ExecutionDetailsEnd'
           )
       
       logger.debug('response....')
       logger.debug(startTime)
       logger.debug(endTime)
       
       errorlogs = client.get_log_events(logGroupName=logGroup,
           logStreamName=logStreamName,
           startTime=startTime,
           #endTime=(startTime+0000000000002),
           startFromHead=True)
       logger.debug('errorlogs...')
       logger.debug(errorlogs)
       err_log=self.construct_details(msg=errorlogs)
       return err_log
        
    
    def getTimeStamp(self, client, logGroup, logStreamName, filterPattern):
        timestamp=None
        msg = client.filter_log_events(logGroupName=logGroup,
           logStreamNames=[logStreamName],
           filterPattern=filterPattern)
           
        events=msg.get('events')
        for event in events:
           if event.get('message')== filterPattern+'\n':
               timestamp = event.get('timestamp')
        
        logger.debug('timestamp...') 
        logger.debug(timestamp)
        return timestamp
        
    def construct_details(self, msg):
        events=msg.get('events')
        data=[]

        for event in events:
            message=event.get('message')
            if message != 'ExecutionDetailsEnd\n':
                data.append(message)
            else:
                break
        
        
        i=0
        while i < len(data):
            if data[i] !='ExecutionDetailsStart\n':
                del data[i]
            else:
                break
        err_log=''
        for element in data:
            err_log+=element
        print(err_log)
        return err_log
        
