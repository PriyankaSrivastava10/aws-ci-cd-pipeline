from awsclients import AwsClients
from botocore.exceptions import ClientError
from cfnpipeline import CFNPipeline
from logger import Logger
import botocore
import boto3
import json

loglevel = 'debug'
logger = Logger(loglevel=loglevel)
logger.info('New Lambda container initialised, logging configured.')
clients = AwsClients(logger)
pipeline_run = CFNPipeline(logger, clients)
err = ''

def __init__(self, logger, clients):
        self.clients = clients
        self.logger = logger
        return

def get_emails(configs):
    emails = []
    global err
    for artifact in configs.keys():
            for config in configs[artifact]:
                if 'notify'not in config or config['notify'] is None or len(config['notify']) == 0:
                    err = "No emails !!!"
                    logger.debug(err)
                else:
                    for email in config['notify']:
                        logger.debug("email: "+email)
                        if email not in emails:
                            emails.append(email)
    logger.debug("emails..")
    logger.debug(emails)
    return emails

def emailSubscription(email, sns_client, sns_topic):
	subscriptionList=[]
	response = sns_client.list_subscriptions_by_topic(TopicArn=sns_topic)
	
	logger.debug("subscriptions..")
	logger.debug(response)
	if response == None:
		return False
	logger.debug("testing..")
	subscriptionList = response.get('Subscriptions')
	for subscription in subscriptionList:
		logger.debug(subscription)
		logger.debug(subscription.get('Endpoint'))
		if email == subscription.get('Endpoint'):
			return True
		
	return False
	
def lambda_handler(event, context):
    try:
        logger.config(context.aws_request_id)
        logger.debug("Handler starting...")
        logger.debug(event)
        pipeline_run.consume_event(event, context, loglevel=loglevel)
        logger.info({'event': 'new_invoke'})
        sns_topic=pipeline_run.report_sns_topic
        errors=[]
        success=[]
        msg = ''
        emailList = get_emails(pipeline_run.ci_configs)
        if len(emailList) == 0:
            msg = "No emails to configure!!"
            errors.append(msg)
        else:
            logger.debug("length...")
            logger.debug(len(emailList))
            sns_region=""
            sns_client=""
            if sns_topic:
                sns_region = sns_topic.split(':')[3]
                sns_client = clients.get('sns', sns_region)
                for email in emailList:
					if not emailSubscription(email, sns_client, sns_topic):
						try:
							sns_client.subscribe(TopicArn=sns_topic, Protocol='email', Endpoint=email)
							msg = "Subscribed"
							logger.info("The email %s subscribed successfully" % (email))
							success.append([email, msg])
						except ClientError as e:
							msg = "The email %s could not subscribe. Error: %s" % (email, e.message)
							logger.error(msg)
							#msg = e.message
							errors.append([email,e.message])
        if len(errors) > 0:
            if len(success) > 0:
                msg = "There are %s email(s) that have errors" % (len(errors))
            logger.info(msg)
            logger.error(errors)
            pipeline_run.put_job_failure(msg)
        else:
            pipeline_run.put_job_success("success")
            #pipeline_run.put_job_failure("%s emails could not subscribe" % (len(errors)))
            
            
    except Exception as e:
        logger.error(e.message)
        pipeline_run.put_job_failure(str(e))
    